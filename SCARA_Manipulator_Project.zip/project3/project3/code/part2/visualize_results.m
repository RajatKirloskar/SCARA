function vis = visualize_results(q,t, q_err, qdot_err)

addpath("visualization/")

    q1 = q(1,:,:);
    q2 = q(2,:,:);
    q3 = q(3,:,:);
    q4 = q(4,:,:);

    p1 = q_err(1,:,:);
    p2 = q_err(2,:,:);
    p3 = q_err(3,:,:);
    p4 = q_err(4,:,:);

    v1 = qdot_err(1,:,:);
    v2 = qdot_err(2,:,:);
    v3 = qdot_err(3,:,:);
    v4 = qdot_err(4,:,:);

    qq1(:,1) = q1(1,1,:);
    qq2(:,1) = q2(1,1,:);
    qq3(:,1) = q3(1,1,:);
    qq4(:,1) = q4(1,1,:);

    vel1(:,1) = v1(1,1,:);
    vel2(:,1) = v2(1,1,:);
    vel3(:,1) = v3(1,1,:);
    vel4(:,1) = v4(1,1,:);

    pos1(:,1) = p1(1,1,:);
    pos2(:,1) = p2(1,1,:);
    pos3(:,1) = p3(1,1,:);
    pos4(:,1) = p4(1,1,:);

   figure(1)
    title("Position Error")
    xlabel("Time")
    ylabel("Position")
    subplot(5,1,1); plot(t, pos1);
    title("Position Error")
    xlabel("Time")
    ylabel("Position")
    subplot(5,1,2); plot(t, pos2);
    title("Position Error")
    xlabel("Time")
    ylabel("Position")
    subplot(5,1,3); plot(t, pos3);
    title("Position Error")
    xlabel("Time")
    ylabel("Position")
    subplot(5,1,4); plot(t, pos4);
    title("Position Error")
    xlabel("Time")
    ylabel("Position")
    subplot(5,1,5);


    figure(2)
    title("Velocity Error")
    xlabel("Time")
    ylabel("Velocity")
    subplot(5,1,1); plot(t, vel1);
    title("Velocity Error")
    xlabel("Time")
    ylabel("Velocity")
    subplot(5,1,2); plot(t, vel2);
    title("Velocity Error")
    xlabel("Time")
    ylabel("Velocity")
    subplot(5,1,3); plot(t, vel3);
    title("Velocity Error")
    xlabel("Time")
    ylabel("Velocity")
    subplot(5,1,4); plot(t, vel4);
    title("Velocity Error")
    xlabel("Time")
    ylabel("Velocity")
    subplot(5,1,5);


    figure(3)
    title("Joint Variable Error");
    xlabel("Time");
    ylabel("Joint Value");
    subplot(5,1,1); plot(t, qq1);
    title("Joint Variable Error");
    xlabel("Time");
    ylabel("Joint Value");
    subplot(5,1,2); plot(t, qq2);
    title("Joint Variable Error");
    xlabel("Time");
    ylabel("Joint Value");
    subplot(5,1,3); plot(t, qq3);
    title("Joint Variable Error");
    xlabel("Time");
    ylabel("Joint Value");
    subplot(5,1,4); plot(t, qq4);
    title("Joint Variable Error");
    xlabel("Time");
    ylabel("Joint Value");
    subplot(5,1,5);

end