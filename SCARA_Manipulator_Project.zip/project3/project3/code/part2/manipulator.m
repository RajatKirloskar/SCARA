function qdd = manipulator(u,q,qdot)

a1 = 0.5;
a2 = 0.5;

kr1 = 1;
kr2 = 1;
kr3 = 50;
kr4 = 20;

F1 = 0.0001;
F2 = 0.0001;
F3 = 0.01;
F4 = 0.005;

g0 = [0 0 -9.8]';

F = [kr1^2*F1 0 0 0
     0 kr2^2*F2 0 0
     0 0 kr3^2*F3 0
     0 0 0 kr4^2*F4];

C = [(-55/8)*sin(q(2))*qdot(2) (-55/8)*sin(q(2))*(qdot(1)+qdot(2)) 0 0
     (55/8)*sin(q(2))*qdot(1) 0 0 0
     0 0 0 0 
     0 0 0 0];

mb = [1 0 0 0;
      0 1 0 0;
      0 0 1 1;
      0 0 0 1];

theta1 = q(1);
theta2 = q(2);
d3 = q(3);
theta4 = q(4);

m1 = dk(theta1,0,a1,0);
m2 = dk(theta2,0,a2,0);
m3 = dk(0,-d3,0,0);
m4 = dk(theta4,0,0,0);

M = m1*m2*m3*m4;

A_b0 = mb;
A_b1 = (mb*m1);
A_b2 = (mb*m1*m2);
A_b3 = (mb*m1*m2*m3);
A_b4 = (mb*M);

p0 = A_b0(1:3,4);
p1 = A_b1(1:3,4);
p2 = A_b2(1:3,4);
p3 = A_b3(1:3,4);
p4 = A_b4(1:3,4);

p4_p0 = A_b4(1:3,4) - A_b0(1:3,4);
p4_p1 = A_b4(1:3,4) - A_b1(1:3,4);
p4_p2 = A_b4(1:3,4) - A_b2(1:3,4);
p4_p3 = A_b4(1:3,4) - A_b3(1:3,4);

p4_p0 = p4_p0.';
p4_p1 = p4_p1.';
p4_p2 = p4_p2.';
p4_p3 = p4_p3.';

l1 = 0.25;
l2 = 0.25; 
l3 = 0;
l4 = 0;

pl1 = (p0 + [l1*cos(theta1),l1*sin(theta1),0]');
pl2 = (p1 + [l2*cos(theta1 + theta2),l2*sin(theta1+theta2),0]');
pl3 = p2;
pl4 = p3;

%size(pl1)

mass_link1 = 25;
mass_link2 = 25;
mass_link3 = 10;
mass_link4 = 5;

zb0 = A_b0(1:3,3);
zb1 = A_b1(1:3,3);
zb2 = A_b2(1:3,3);
zb3 = A_b3(1:3,3);

zb0 = zb0';
zb1 = zb1';
zb2 = zb2';
zb3 = zb3';

z0_cross_p4_p0 = cross(zb0,p4_p0);
z1_cross_p4_p1 = cross(zb1,p4_p1);
z3_cross_p4_p3 = cross(zb3,p4_p3);

Jacobian = [z0_cross_p4_p0(1,1) z1_cross_p4_p1(1,1) zb2(1,1) z3_cross_p4_p3(1,1);
            z0_cross_p4_p0(1,2) z1_cross_p4_p1(1,2) zb2(1,2) z3_cross_p4_p3(1,2);
            z0_cross_p4_p0(1,3) z1_cross_p4_p1(1,3) zb2(1,3) z3_cross_p4_p3(1,3);
            zb0(1,1) zb1(1,1) 0 zb3(1,1);
            zb0(1,2) zb1(1,2) 0 zb3(1,2);
            zb0(1,3) zb1(1,3) 0 zb3(1,3)];

Jo_l1 = Jacobian(4:6,1);
Jp_m1 = cross(zb0', (p0-p0));
Jo_m1 = kr1*zb0';


Jp_l2 = cross(zb1', (p1 + [l2*cos(theta1+theta2),l2*sin(theta1+theta2),0]')-p1);
Jo_l2 = Jacobian(4:6,2);
Jp_m2 = cross(zb1', (p1-p1));
Jo_m2 = kr2*zb1';


Jp_l3 = Jacobian(1:3,3);
Jo_l3 = Jacobian(4:6,3);
Jp_m3 = Jacobian(1:3,3);
Jo_m3 = kr3*zb2';

Jp_l4 = cross(zb3', (p3 + [l4*cos(theta1+theta2),l4*sin(theta1+theta2),0]')-p3);
Jo_l4 = Jacobian(4:6,4);
Jp_m4 = cross(zb3', (p3-p3));
Jo_m4 = kr4*zb3';

I_m1 = 0.0001;
I_m2 = 0.0001;
I_m3 = 0.01;
I_m4 = 0.005;

I_l1 = 5;
I_l2 = 5;
I_l3 = 0;
I_l4 = 1;

mass_link1 = 25;
mass_link2 = 25;
mass_link3 = 10;
mass_link4 = 5;

Jp1_l1 = cross(zb0, pl1-p0);
Jp1_l2 = cross(zb0, pl2-p0);
Jp1_l3 = cross(zb0, pl3-p0);
Jp1_l4 = cross(zb0, pl4-p0);

Jp2_l1 = cross(zb1, pl1-p1);
Jp2_l2 = cross(zb1, pl2-p1);
Jp2_l3 = cross(zb1, pl3-p1);
Jp2_l4 = cross(zb1, pl4-p1);

Jp3_l1 = zb2;
Jp3_l2 = zb2;
Jp3_l3 = zb2;
Jp3_l4 = zb2;


Jp4_l1 = cross(zb3, pl4-p3);
Jp4_l2 = cross(zb3, pl4-p3);
Jp4_l3 = cross(zb3, pl4-p3);
Jp4_l4 = cross(zb3, pl4-p3);


Jp_link1 = [Jp1_l1',zeros(3,1),zeros(3,1),zeros(3,1)];
Jo_link1 = [Jo_l1,zeros(3,1),zeros(3,1),zeros(3,1)];
%Jp_motor1 = [Jp_m1,zeros(3,1),zeros(3,1),zeros(3,1)];
Jo_motor1 = [Jo_m1,zeros(3,1),zeros(3,1),zeros(3,1)];


Jp_link2 = [Jp1_l2',Jp2_l2',zeros(3,1),zeros(3,1)];
Jo_link2 = [Jo_l1,Jo_l2,zeros(3,1),zeros(3,1)];
%Jp_motor2 = [Jp_m1,Jp_m2,zeros(3,1),zeros(3,1)];
Jo_motor2 = [Jo_l1,Jo_m2,zeros(3,1),zeros(3,1)];

Jp_link3 = [Jp1_l3',Jp2_l3',Jp3_l3',zeros(3,1)];
Jo_link3 = [Jo_l1,Jo_l2,zeros(3,1),zeros(3,1)];
%Jp_motor3 = [Jp_m1,Jp_m2,Jp_m3,zeros(3,1)];
Jo_motor3 = [Jo_l1,Jo_l2,Jo_m3,zeros(3,1)];

Jp_link4 = [Jp1_l4',Jp2_l4',Jp3_l4',Jp4_l4'];
Jo_link4 = [Jo_l1,Jo_l2,Jo_l3,Jo_l4];
%Jp_motor4 = [Jp_m1,Jp_m2,Jp_m3,Jp_m4];
Jo_motor4 = [Jo_l1,Jo_l2,Jo_l3,Jo_m4];

B1 = mass_link1*(Jp_link1'*Jp_link1) + Jo_link1'*I_l1*Jo_link1 + Jo_motor1'*I_m1*Jo_motor1; 
B2 = mass_link2*(Jp_link2'*Jp_link2) + Jo_link2'*I_l2*Jo_link2 + Jo_motor2'*I_m2*Jo_motor2;
B3 = mass_link3*(Jp_link3'*Jp_link3) + Jo_link3'*I_l3*Jo_link3 + Jo_motor3'*I_m3*Jo_motor3;
B4 = mass_link4*(Jp_link4'*Jp_link4) + Jo_link4'*I_l4*Jo_link4 + Jo_motor4'*I_m4*Jo_motor4;


Bq = (B1+B2+B3+B4);

g1 = -(mass_link1*g0'*Jp1_l1') + (mass_link2*g0'*Jp1_l2') + (mass_link3*g0'*Jp1_l3') + (mass_link4*g0'*Jp1_l4');
g2 = -(mass_link1*g0'*Jp2_l1') + (mass_link2*g0'*Jp2_l2') + (mass_link3*g0'*Jp2_l3') + (mass_link4*g0'*Jp2_l4');
g3 = -(mass_link1*g0'*Jp3_l1') + (mass_link2*g0'*Jp3_l2') + (mass_link3*g0'*Jp3_l3') + (mass_link4*g0'*Jp3_l4');
g4 = -(mass_link1*g0'*Jp4_l1') + (mass_link2*g0'*Jp4_l2') + (mass_link3*g0'*Jp4_l3') + (mass_link4*g0'*Jp4_l4');


g = [g1;g2;g3;g4];
a = C*qdot + F*qdot + g;

qdd = Bq\(u-a);

end

function [m] = dk(theta,d,a,alpha)
    m = [cos(theta) -sin(theta)*cos(alpha) sin(theta)*sin(alpha) a*cos(theta);
         sin(theta) cos(theta)*cos(alpha) -cos(theta)*sin(alpha) a*sin(theta);
         0 sin(alpha) cos(alpha) d;
         0 0 0 1];
end
