clear all
close all
clc
vrclear
vrclose

load('generated_traj.mat');
control;
sim('control.mdl', t);
visualize_results(q,t, q_err, qdot_err)
SCARA_VR_VISUALIZE(squeeze(q(:,1,:)), false);