function nq=n(qdot,q)

a1 = 0.5;
a2 = 0.5;

kr1 = 1;
kr2 = 1;
kr3 = 50;
kr4 = 20;

F1 = 0.0001;
F2 = 0.0001;
F3 = 0.01;
F4 = 0.005;

g0 = [0 0 -9.8]';

F = [kr1^2*F1 0 0 0
     0 kr2^2*F2 0 0
     0 0 kr3^2*F3 0
     0 0 0 kr4^2*F4];

C = [(-55/8)*sin(q(2))*qdot(2) (-55/8)*sin(q(2))*(qdot(1)+qdot(2)) 0 0
     (55/8)*sin(q(2))*qdot(1) 0 0 0
     0 0 0 0 
     0 0 0 0];

mb = [1 0 0 0;
      0 1 0 0;
      0 0 1 1;
      0 0 0 1];

theta1 = q(1);
theta2 = q(2);
d3 = q(3);
theta4 = q(4);

m1 = dk(theta1,0,a1,0);
m2 = dk(theta2,0,a2,0);
m3 = dk(0,-d3,0,0);
m4 = dk(theta4,0,0,0);

M = m1*m2*m3*m4;

A_b0 = mb;
A_b1 = (mb*m1);
A_b2 = (mb*m1*m2);
A_b3 = (mb*m1*m2*m3);
A_b4 = (mb*M);

p0 = A_b0(1:3,4);
p1 = A_b1(1:3,4);
p2 = A_b2(1:3,4);
p3 = A_b3(1:3,4);
p4 = A_b4(1:3,4);

l1 = 0.25;
l2 = 0.25; 
l3 = 0;
l4 = 0;

pl1 = (p0 + [l1*cos(theta1),l1*sin(theta1),0]');
pl2 = (p1 + [l2*cos(theta1 + theta2),l2*sin(theta1+theta2),0]');
pl3 = p2;
pl4 = p3;


mass_link1 = 25;
mass_link2 = 25;
mass_link3 = 10;
mass_link4 = 5;

zb0 = A_b0(1:3,3);
zb1 = A_b1(1:3,3);
zb2 = A_b2(1:3,3);
zb3 = A_b3(1:3,3);


Jp1_l1 = cross(zb0, pl1-p0);
Jp1_l2 = cross(zb0, pl2-p0);
Jp1_l3 = cross(zb0, pl3-p0);
Jp1_l4 = cross(zb0, pl4-p0);

Jp2_l1 = cross(zb1, pl1-p1);
Jp2_l2 = cross(zb1, pl2-p1);
Jp2_l3 = cross(zb1, pl3-p1);
Jp2_l4 = cross(zb1, pl4-p1);

Jp3_l1 = zb2;
Jp3_l2 = zb2;
Jp3_l3 = zb2;
Jp3_l4 = zb2;

Jp4_l1 = cross(zb3, pl4-p3);
Jp4_l2 = cross(zb3, pl4-p3);
Jp4_l3 = cross(zb3, pl4-p3);
Jp4_l4 = cross(zb3, pl4-p3);

g1 = -(mass_link1*g0'*Jp1_l1) + (mass_link2*g0'*Jp1_l2) + (mass_link3*g0'*Jp1_l3) + (mass_link4*g0'*Jp1_l4);
g2 = -(mass_link1*g0'*Jp2_l1) + (mass_link2*g0'*Jp2_l2) + (mass_link3*g0'*Jp2_l3) + (mass_link4*g0'*Jp2_l4);
g3 = -(mass_link1*g0'*Jp3_l1) + (mass_link2*g0'*Jp3_l2) + (mass_link3*g0'*Jp3_l3) + (mass_link4*g0'*Jp3_l4);
g4 = -(mass_link1*g0'*Jp4_l1) + (mass_link2*g0'*Jp4_l2) + (mass_link3*g0'*Jp4_l3) + (mass_link4*g0'*Jp4_l4);


g = [g1;g2;g3;g4];
nq = C*qdot + F*qdot + g;

end

function [m] = dk(theta,d,a,alpha)
    m = [cos(theta) -sin(theta)*cos(alpha) sin(theta)*sin(alpha) a*cos(theta);
         sin(theta) cos(theta)*cos(alpha) -cos(theta)*sin(alpha) a*sin(theta);
         0 sin(alpha) cos(alpha) d;
         0 0 0 1];
end