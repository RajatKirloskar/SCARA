function q_dotdot = jacobian_inverse(x,q)

[Jacobian,~] = jacobian(q,0);

jacobian_inv = (inv(Jacobian));
q_dotdot = jacobian_inv*x;

end